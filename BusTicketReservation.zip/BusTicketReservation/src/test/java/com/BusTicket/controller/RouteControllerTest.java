package com.BusTicket.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.BusTicket.exception.AdminException;
import com.BusTicket.exception.RouteException;
import com.BusTicket.model.Route;
import com.BusTicket.service.RouteService;

class RouteControllerTest {

    @Mock
    private RouteService routeService;

    @InjectMocks
    private RouteController routeController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddRoute_ValidRoute_AddsRoute() throws RouteException, AdminException {
        Route route = new Route();
        Route addedRoute = new Route();
        when(routeService.addRoute(any(Route.class), anyString())).thenReturn(addedRoute);

        ResponseEntity<Route> responseEntity = routeController.addRoute(route, "key");

        assertEquals(HttpStatus.ACCEPTED.value(), responseEntity.getStatusCodeValue());
        assertEquals(addedRoute, responseEntity.getBody());
    }

    @Test
    void testGetAllRoutes_NoExceptions_ReturnsAllRoutes() throws RouteException {
        List<Route> routes = new ArrayList<>();
        when(routeService.viewAllRoute()).thenReturn(routes);

        ResponseEntity<List<Route>> responseEntity = routeController.getAllRouteHandler();

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertEquals(routes, responseEntity.getBody());
    }

    @Test
    void testGetRouteById_ValidId_ReturnsRoute() throws RouteException {
        Integer routeId = 1;
        Route route = new Route();
        when(routeService.viewRoute(anyInt())).thenReturn(route);

        ResponseEntity<Route> responseEntity = routeController.getAllRouteByRouteIdHandler(routeId);

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertEquals(route, responseEntity.getBody());
    }

    @Test
    void testUpdateRoute_ValidRoute_UpdatesRoute() throws RouteException, AdminException {
        Route route = new Route();
        Route updatedRoute = new Route();
        when(routeService.updateRoute(any(Route.class), anyString())).thenReturn(updatedRoute);

        ResponseEntity<Route> responseEntity = routeController.updateRoute(route, "key");

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertEquals(updatedRoute, responseEntity.getBody());
    }

    @Test
    void testDeleteRoute_ValidId_DeletesRoute() throws RouteException, AdminException {
        Integer routeId = 1;
        Route route = new Route();
        when(routeService.deleteRoute(anyInt(), anyString())).thenReturn(route);

        ResponseEntity<Route> responseEntity = routeController.DeleteRoute(routeId, "key");

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertEquals(route, responseEntity.getBody());
    }
}
