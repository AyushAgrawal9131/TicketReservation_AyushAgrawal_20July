package com.BusTicket.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.BusTicket.exception.AdminException;
import com.BusTicket.exception.UserException;
import com.BusTicket.model.User;
import com.BusTicket.service.UserService;

class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testHelloEndpoint_ShouldReturnHello() {
        String result = userController.hello();
        assertEquals("Hello", result);
    }

    @Test
    void testRegisterUser_ValidUser_CreatesUser() throws UserException {
        User user = new User();
        User savedUser = new User();
        when(userService.createUser(any(User.class))).thenReturn(savedUser);

        ResponseEntity<User> responseEntity = userController.registerUser(user);

        assertEquals(HttpStatus.CREATED.value(), responseEntity.getStatusCodeValue());
        assertEquals(savedUser, responseEntity.getBody());
    }

    @Test
    void testUpdateUser_ValidUser_UpdatesUser() throws UserException {
        User user = new User();
        User updatedUser = new User();
        when(userService.updateUser(any(User.class), eq("anyKey"))).thenReturn(updatedUser);

        ResponseEntity<User> responseEntity = userController.updateUser(user, "anyKey");

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertEquals(updatedUser, responseEntity.getBody());
    }

    @Test
    void testDeleteUser_ValidUserId_DeletesUser() throws UserException, AdminException {
        Integer userId = 1;
        User deletedUser = new User();
        when(userService.deleteUser(eq(userId), eq("anyKey"))).thenReturn(deletedUser);

        ResponseEntity<User> responseEntity = userController.deleteUser(userId, "anyKey");

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertEquals(deletedUser, responseEntity.getBody());
    }

    @Test
    void testViewUserById_ValidUserId_ReturnsUser() throws UserException, AdminException {
        Integer userId = 1;
        User user = new User();
        when(userService.viewUserById(eq(userId), eq("anyKey"))).thenReturn(user);

        ResponseEntity<User> responseEntity = userController.viewUserById(userId, "anyKey");

        assertEquals(HttpStatus.FOUND.value(), responseEntity.getStatusCodeValue());
        assertEquals(user, responseEntity.getBody());
    }

    @Test
    void testViewAllUsers_ValidKey_ReturnsUsers() throws UserException, AdminException {
        List<User> users = new ArrayList<>();
        when(userService.viewAllUser(eq("anyKey"))).thenReturn(users);

        ResponseEntity<List<User>> responseEntity = userController.viewAllUser("anyKey");

        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
        assertEquals(users, responseEntity.getBody());
    }
}

