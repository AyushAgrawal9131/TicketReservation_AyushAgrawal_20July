package com.BusTicket.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.BusTicket.exception.AdminException;
import com.BusTicket.exception.BusException;
import com.BusTicket.model.Bus;
import com.BusTicket.service.BusService;

public class BusControllerTest {

    @Mock
    private BusService busService;

    @InjectMocks
    private BusController busController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddBusHandler_ValidBus_CreatesBus() throws BusException, AdminException {
        Bus bus = new Bus();
        bus.setBusName("TestBus");
        bus.setDriverName("TestDriver");
        when(busService.addBus(any(Bus.class), anyString())).thenReturn(bus);

        ResponseEntity<Bus> responseEntity = busController.addBusHandler(bus, "key");

        assertEquals(bus, responseEntity.getBody());
    }
}
