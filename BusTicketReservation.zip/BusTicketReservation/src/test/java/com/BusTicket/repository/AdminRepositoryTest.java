package com.BusTicket.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.BusTicket.model.Admin;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class AdminRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private AdminRepository adminRepository;

    @Test
    void shouldFindAdminByEmail() {
        // Given
        String email = "admin@example.com";
        Admin admin = new Admin();
        admin.setEmail(email);
        admin.setName("John");
        admin.setPassword("John@123");
        

        entityManager.persist(admin);
        entityManager.flush();

        // When
        List<Admin> foundAdmins = adminRepository.findByEmail(email);

        // Then
        assertThat(foundAdmins).containsExactlyInAnyOrder(admin);
    }
}
