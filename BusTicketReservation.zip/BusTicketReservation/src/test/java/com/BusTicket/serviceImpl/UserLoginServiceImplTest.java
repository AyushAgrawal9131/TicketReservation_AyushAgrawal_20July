package com.BusTicket.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.BusTicket.exception.LoginException;
import com.BusTicket.model.CurrentUserSession;
import com.BusTicket.model.User;
import com.BusTicket.model.UserLoginDTO;
import com.BusTicket.repository.CurrentUserSessionRepository;
import com.BusTicket.repository.UserRepository;

class UserLoginServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private CurrentUserSessionRepository userSessionRepository;

    @InjectMocks
    private UserLoginServiceImpl userLoginService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testUserLogin_InvalidEmail_ThrowsLoginException() {
        UserLoginDTO userLoginDTO = new UserLoginDTO("invalid@email.com", "password");

        when(userRepository.findByEmail(anyString())).thenReturn(null);

        assertThrows(LoginException.class, () -> userLoginService.userLogin(userLoginDTO));
    }

    @Test
    void testUserLogin_ValidCredentials_CreatesSession() throws LoginException {
    	User user = new User(
                12345, // userID
                "John", // firstName
                "", // lastName can be blank
                "6789123456", // mobile
                "john.doe@example.com", // email
                "SecurePassw0rd!", // password
                List.of() // reservationList is empty
        );
        when(userRepository.findByEmail("ayushagrawal9131@gmail.com")).thenReturn(user);
        when(userSessionRepository.findById(1)).thenReturn(Optional.empty());

        UserLoginDTO userLoginDTO = new UserLoginDTO("email@example.com", "password");

        CurrentUserSession session = userLoginService.userLogin(userLoginDTO);

        verify(userSessionRepository, times(1)).save(any(CurrentUserSession.class));
        assertNotNull(session);
    }

    @Test
    void testUserLogout_ValidKey_LogsOutUser() throws LoginException {
        String key = "validKey";
        when(userSessionRepository.findByUuid(anyString())).thenReturn(new CurrentUserSession());

        String result = userLoginService.userLogout(key);

        verify(userSessionRepository, times(1)).delete(any(CurrentUserSession.class));
        assertEquals("User logged out!", result);
    }

    @Test
    void testUserLogout_InvalidKey_ThrowsLoginException() {
        String key = "invalidKey";

        when(userSessionRepository.findByUuid(anyString())).thenReturn(null);

        assertThrows(LoginException.class, () -> userLoginService.userLogout(key));
    }
}
