package com.BusTicket.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.BusTicket.exception.RouteException;
import com.BusTicket.model.CurrentAdminSession;
import com.BusTicket.model.Route;
import com.BusTicket.repository.AdminRepository;
import com.BusTicket.repository.CurrentAdminSessionRepository;
import com.BusTicket.repository.RouteRepository;

class RouteServiceImplTest {

    @Mock
    private RouteRepository routeRepository;

    @Mock
    private CurrentAdminSessionRepository currentAdminSessionRepository;

    @Mock
    private AdminRepository adminRepository;

    @InjectMocks
    private RouteServiceImpl routeService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

   

    @Test
    void testViewAllRoute_NoRoutes_ThrowsException() {
        when(routeRepository.findAll()).thenReturn(new ArrayList<>());

        assertThrows(RouteException.class, () -> routeService.viewAllRoute());
    }

    @Test
    void testViewRoute_ValidRouteId_ReturnsRoute() throws Exception {
        int routeId = 1;
        when(routeRepository.findById(routeId)).thenReturn(Optional.of(new Route()));

        Route route = routeService.viewRoute(routeId);

        assertNotNull(route);
    }

    

    
}

