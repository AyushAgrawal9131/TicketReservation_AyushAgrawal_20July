package com.BusTicket.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.BusTicket.exception.AdminException;
import com.BusTicket.model.Admin;
import com.BusTicket.model.CurrentAdminSession;
import com.BusTicket.repository.AdminRepository;
import com.BusTicket.repository.CurrentAdminSessionRepository;
import com.BusTicket.serviceImpl.AdminServiceImpl;

class AdminServiceImplTest {

    @Mock
    private AdminRepository adminRepository;

    @Mock
    private CurrentAdminSessionRepository adminSessionRepository;

    @InjectMocks
    private AdminServiceImpl adminService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateAdmin_ExistingEmailThrowsException() {
        // Given
        Admin admin = new Admin();
        admin.setEmail("existing@email.com");
        admin.setName("John"); // Setting common name
        admin.setPassword("John@123"); // Setting common password

        when(adminRepository.findByEmail(eq(admin.getEmail()))).thenReturn(List.of(new Admin()));

        // When & Then
        assertThrows(AdminException.class, () -> adminService.createAdmin(admin));
    }



    @Test
    void testUpdateAdmin_InvalidKey_ThrowsException() {
        // Given
        Admin admin = new Admin();
        admin.setAdminID(1); // Assuming Admin ID is set somewhere
        admin.setName("John"); // Setting common name
        admin.setPassword("John@123"); // Setting common password

        when(adminSessionRepository.findById(1)).thenReturn(null);

        // When & Then
        assertThrows(AdminException.class, () -> adminService.updateAdmin(admin, "invalidKey"));
    }
}

