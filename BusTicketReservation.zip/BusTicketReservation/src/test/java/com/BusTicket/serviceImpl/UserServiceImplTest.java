package com.BusTicket.serviceImpl;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.BusTicket.exception.AdminException;
import com.BusTicket.exception.UserException;
import com.BusTicket.model.CurrentAdminSession;
import com.BusTicket.model.CurrentUserSession;
import com.BusTicket.model.User;
import com.BusTicket.repository.CurrentAdminSessionRepository;
import com.BusTicket.repository.CurrentUserSessionRepository;
import com.BusTicket.repository.UserRepository;

class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private CurrentUserSessionRepository userSessionRepository;

    @Mock
    private CurrentAdminSessionRepository adminSessionRepository;

    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateUser_UserExists_ThrowsUserException() {
        User user = new User();
        user.setMobile("existingUser@example.com");

        when(userRepository.findByEmail(anyString())).thenReturn(new User());

        assertThrows(UserException.class, () -> userService.createUser(user));
    }


    

    

   
}
