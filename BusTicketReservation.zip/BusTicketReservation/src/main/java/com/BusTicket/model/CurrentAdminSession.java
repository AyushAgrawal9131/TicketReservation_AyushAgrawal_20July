package com.BusTicket.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class CurrentAdminSession {
    @Id
    @Column(unique = true)
    private Integer adminID;
    private String aid;
    private LocalDateTime time;
    
    
    
	public CurrentAdminSession() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CurrentAdminSession(Integer adminID, String aid, LocalDateTime time) {
		super();
		this.adminID = adminID;
		this.aid = aid;
		this.time = time;
	}
	public Integer getAdminID() {
		return adminID;
	}
	public void setAdminID(Integer adminID) {
		this.adminID = adminID;
	}
	public String getAid() {
		return aid;
	}
	public void setAid(String aid) {
		this.aid = aid;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
    
    
}