package com.BusTicket.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class CurrentUserSession {
    @Id
    @Column(unique = true)
    private Integer userID;
    private String uuid;
    private LocalDateTime time;
	public CurrentUserSession(Integer userID, String uuid, LocalDateTime time) {
		super();
		this.userID = userID;
		this.uuid = uuid;
		this.time = time;
	}
	public CurrentUserSession() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getUserID() {
		return userID;
	}
	public void setUserID(Integer userID) {
		this.userID = userID;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
    
    
}