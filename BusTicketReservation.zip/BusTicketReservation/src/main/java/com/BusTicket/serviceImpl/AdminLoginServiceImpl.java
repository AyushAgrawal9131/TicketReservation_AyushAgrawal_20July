package com.BusTicket.serviceImpl;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BusTicket.exception.AdminException;
import com.BusTicket.exception.LoginException;
import com.BusTicket.model.Admin;
import com.BusTicket.model.AdminLoginDTO;
import com.BusTicket.model.CurrentAdminSession;
import com.BusTicket.repository.AdminRepository;
import com.BusTicket.repository.CurrentAdminSessionRepository;
import com.BusTicket.service.AdminLoginService;


@Service
public class AdminLoginServiceImpl implements AdminLoginService{

    @Autowired
    private CurrentAdminSessionRepository adminSessionRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public CurrentAdminSession adminLogin(AdminLoginDTO loginDTO) throws AdminException, LoginException {
        List<Admin> admins = adminRepository.findByEmail(loginDTO.getEmail());
        
        if(admins.isEmpty()) {
        	throw new AdminException("Please enter a valid email!");
        }
        
        Admin registeredAdmin = admins.get(0);
        
        if(registeredAdmin == null) throw new AdminException("Please enter a valid email!");

        if(registeredAdmin.getPassword().equals(loginDTO.getPassword())){
            SecureRandom secureRandom = new SecureRandom();
            byte[] keyBytes = new byte[10];
            secureRandom.nextBytes(keyBytes);
            
            String key = Base64.getEncoder().encodeToString(keyBytes);
            
            CurrentAdminSession adminSession = new CurrentAdminSession();
            adminSession.setAdminID(registeredAdmin.getAdminID());
            adminSession.setAid(key);
            adminSession.setTime(LocalDateTime.now());
            return adminSessionRepository.save(adminSession);
        }else
            throw new LoginException("Please enter valid password!");
    }

    @Override
    public String adminLogout(String key) throws LoginException {
        CurrentAdminSession currentAdminSession = adminSessionRepository.findById(key);
        if(currentAdminSession == null) throw new LoginException("Invalid Admin login key!");
        adminSessionRepository.delete(currentAdminSession);
        return "Admin logged out!";
    }
}