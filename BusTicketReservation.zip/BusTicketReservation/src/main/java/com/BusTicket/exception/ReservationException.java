package com.BusTicket.exception;


public class ReservationException extends Exception{
    public ReservationException(){}

    public ReservationException(String message){
        super(message);
    }
}