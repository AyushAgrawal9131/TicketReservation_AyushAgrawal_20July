package com.BusTicket.exception;

public class RouteException  extends Exception{
	
	public RouteException(String message) {
		super(message);
	}
	
	public RouteException() {
		
	}
}