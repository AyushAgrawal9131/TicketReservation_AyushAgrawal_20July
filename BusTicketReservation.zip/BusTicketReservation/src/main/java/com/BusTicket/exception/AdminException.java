package com.BusTicket.exception;

public class AdminException extends Exception{
    public AdminException(String message) {
        super(message);
    }
}
