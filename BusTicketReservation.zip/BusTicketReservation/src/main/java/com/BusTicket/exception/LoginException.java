package com.BusTicket.exception;

public class LoginException extends Exception{
    public LoginException(String message) {
        super(message);
    }
}