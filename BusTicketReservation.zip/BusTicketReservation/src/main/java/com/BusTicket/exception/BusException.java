package com.BusTicket.exception;

public class BusException extends Exception{
    public BusException(){}
    public BusException(String msg){
    	super(msg);
    	}
}

