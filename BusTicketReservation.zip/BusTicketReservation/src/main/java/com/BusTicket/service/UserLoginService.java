package com.BusTicket.service;

import com.BusTicket.exception.LoginException;
import com.BusTicket.model.CurrentUserSession;
import com.BusTicket.model.UserLoginDTO;

public interface UserLoginService {
    public CurrentUserSession userLogin(UserLoginDTO userLoginDTO) throws LoginException;
    public String userLogout(String key) throws LoginException;
}
