package com.BusTicket.service;

import com.BusTicket.exception.LoginException;
import com.BusTicket.exception.AdminException;
import com.BusTicket.model.AdminLoginDTO;
import com.BusTicket.model.CurrentAdminSession;

public interface AdminLoginService {
    public CurrentAdminSession adminLogin(AdminLoginDTO loginDTO) throws AdminException,LoginException;
    public String adminLogout(String key) throws LoginException;
}
