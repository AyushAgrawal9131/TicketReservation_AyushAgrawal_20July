package com.BusTicket.service;

import com.BusTicket.exception.AdminException;
import com.BusTicket.model.Admin;

public interface AdminService {
    public Admin createAdmin(Admin admin) throws AdminException;
    public Admin updateAdmin(Admin admin, String key) throws AdminException;
}
